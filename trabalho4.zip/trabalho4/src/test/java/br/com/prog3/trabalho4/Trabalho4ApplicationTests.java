package br.com.prog3.trabalho4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabalho4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
